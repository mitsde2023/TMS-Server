const cloudinary = require('cloudinary').v2; 

cloudinary.config({
    cloud_name: 'dtgpxvmpl',
    api_key: '113933747541586',
    api_secret: 'ubPVZqWAV1oOkGdwfuchq-l01i8',
});                                                                                                                           

module.exports = cloudinary;